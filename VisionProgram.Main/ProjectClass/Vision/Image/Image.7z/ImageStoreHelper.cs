﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using Cognex.VisionPro.ImageFile;
using System.IO;
using System.Globalization;
using VisionProgram.ProjectClass;
using System.Drawing.Imaging;
using VisionProgram.Main.ProjectClass;

namespace VisionProgram.Common
{
    /// <summary>
    /// 保存图片辅助类
    /// </summary>
    public static class ImageStoreHelper
    {
        /// <summary>
        /// 存图模式
        /// </summary>
        public enum SAVEOPPORTUNITY { NONE = 0, ONLYOK = 1, ONLYNG = 2, ALL = 3 }

        /// <summary>
        /// 清除历史存图
        /// </summary>
        public static void CleanHistoryPicture(int index)
        {
            string temp;
            DateTime dirDateTime;
            try
            {
                //原始图像文件夹
                if (!Directory.Exists(Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawImagePosition))
                    Directory.CreateDirectory(Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawImagePosition);
                //结果图片文件夹
                if (!Directory.Exists(Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImagePosition))
                    Directory.CreateDirectory(Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImagePosition);

                foreach (string dirname in Directory.GetDirectories(Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawImagePosition))
                {
                    temp = dirname.Substring(dirname.LastIndexOf('\\') + 1);
                    dirDateTime = DateTime.ParseExact(temp, "yyyy-MM-dd", CultureInfo.CurrentCulture, DateTimeStyles.None);

                    if ((DateTime.Now - dirDateTime).Days >= Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawKeepingDays)
                    {
                        Directory.Delete(dirname, true);
                    }
                }

                foreach (string dirname in Directory.GetDirectories(Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImagePosition))
                {
                    temp = dirname.Substring(dirname.LastIndexOf('\\') + 1);
                    dirDateTime = DateTime.ParseExact(temp, "yyyy-MM-dd", CultureInfo.CurrentCulture, DateTimeStyles.None);
                    if ((DateTime.Now - dirDateTime).Days >= Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultKeepingDays)
                    {
                        Directory.Delete(dirname, true);
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error("自动清除历史存图出现异常",ex);
            }
        }

        #region VisionPro
        /// <summary>
        /// 存带结果图像
        /// </summary>
        /// <param name="_cd"></param>
        /// <param name="imagename"></param>
        /// <param name="bOK"></param>
        public static void SaveResultImage(CogRecordsDisplay _cd, string imagename, bool bOK, string ymd, string hms,int index)
        {
            if (Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImageSaveOpportunity == SAVEOPPORTUNITY.NONE)
                return;
            if ((Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImageSaveOpportunity == SAVEOPPORTUNITY.ALL)
                || ((Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImageSaveOpportunity == SAVEOPPORTUNITY.ONLYOK) && bOK)
                || ((Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImageSaveOpportunity == SAVEOPPORTUNITY.ONLYNG) && !bOK))
            {
                SaveResultImageHelper(_cd, imagename + (bOK ? "_OK" : "_NG"), ymd, hms,index);
                return;
            }
        }

        /// <summary>
        /// 存结果图
        /// </summary>
        /// <param name="_cd"></param>
        /// <param name="imagename"></param>
        private static void SaveResultImageHelper(CogRecordsDisplay _cd, string imageName, string ymd, string hms,int index)
        {
            System.Threading.ThreadPool.QueueUserWorkItem((d) =>
            {
                try
                {
                    if (!Directory.Exists(Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImagePosition + @"\" + ymd + @"\" + "CCD" + imageName[0]))
                    {
                        Directory.CreateDirectory(Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImagePosition + @"\" + ymd + @"\" + "CCD" + imageName[0]);
                    }
                    string str = Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImagePosition + @"\" + ymd + @"\" + "CCD" + imageName[0] + @"\" + hms  +"-" + imageName + Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImagePattern;
                    System.Drawing.Image ig = _cd.Display.CreateContentBitmap(Cognex.VisionPro.Display.CogDisplayContentBitmapConstants.Custom, null, 0);
                    string format = Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].ResultImagePattern;
                    switch (format)
                    {
                        case ".bmp":
                            ig.Save(str, ImageFormat.Bmp);
                            break;
                        case ".jpg":
                            ig.Save(str, ImageFormat.Jpeg);
                            break;
                        case ".png":
                            ig.Save(str, ImageFormat.Png);
                            break;
                        case ".tif":
                            ig.Save(str, ImageFormat.Tiff);
                            break;
                        default:
                            ig.Save(str, ImageFormat.Jpeg);
                            break;
                    }
                   
                }
                catch (Exception ex)
                {
                    LogHelper.Error("存相机VP结果图出现异常",ex);
                }
            });
        }

        /// <summary>
        /// 存原图
        /// </summary>
        /// <param name="img"></param>
        /// <param name="imagename"></param>
        /// <param name="bOK"></param>
        public static void SaveRawImage(ICogImage img, string imagename, bool bOK, string ymd, string hms,int index)
        {
            if (Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawImageSaveOpportunity == SAVEOPPORTUNITY.NONE)
                return;
            if ((Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawImageSaveOpportunity == SAVEOPPORTUNITY.ALL)
                || ((Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawImageSaveOpportunity == SAVEOPPORTUNITY.ONLYOK) && bOK)
                || ((Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawImageSaveOpportunity == SAVEOPPORTUNITY.ONLYNG) && !bOK))
            {
                SaveRawImageHelper(img,imagename + (bOK ? "_OK" : "_NG"), ymd, hms,index);
                return;
            }
        }

        /// <summary>
        /// 存原图
        /// </summary>
        /// <param name="img"></param>
        /// <param name="imagename"></param>
        private static void SaveRawImageHelper(ICogImage img, string imageName, string ymd, string hms,int index)
        {
            System.Threading.ThreadPool.QueueUserWorkItem((d) =>
            {
                try
                {
                    if (!Directory.Exists(Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawImagePosition + @"\" + ymd + @"\" + "CCD" + imageName[0]))//2021_07_26\CCD1
                    {
                        Directory.CreateDirectory(Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawImagePosition + @"\" + ymd + @"\" + "CCD" + imageName[0]);
                    }
                    Cognex.VisionPro.ImageFile.CogImageFileTool a = new Cognex.VisionPro.ImageFile.CogImageFileTool();
                    a.InputImage = img;
                    string str = Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawImagePosition + @"\" + ymd + @"\" + "CCD" + imageName[0] + @"\" + hms +"-"+ imageName + Project.Instance().VisionManagerInstance.ImageManagerInstance.ImageParams[index].RawImagePattern;//12_34_45_1-1_OK_.BMP
                    a.Operator.Open(str, Cognex.VisionPro.ImageFile.CogImageFileModeConstants.Write);
                    a.Run();
                    a.Dispose();
                }
                catch (Exception ex)
                {
                    LogHelper.Error("存相机VP原始图出现异常",ex);
                }
            });
        }
        #endregion



       
    }
}
